# Class=1030 (0x0406) - Level II Display

    CLASS2.DISPLAY

## Description

Level II specific display functionality. Also look at [CLASS1.DISPLAY](./class1.display.md) 

## Type=0 (0x00) - General event :id=type0
```VSCP2_TYPE_DISPLAY_GENERAL```
General Event.
----

[filename](./bottom_copyright.md ':include')