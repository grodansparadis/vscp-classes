# Class=1025 (0x0401) - Level II Control

    CLASS2.CONTROL

## Description

Level II Control functionality.
## Type=0 (0x00) - General event :id=type0
```
VSCP2_TYPE_CONTROL_GENERAL
```
General Event.
----

[filename](./bottom_copyright.md ':include')