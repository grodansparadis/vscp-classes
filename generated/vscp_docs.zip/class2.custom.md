# Class=1029 (0x0405) - Level II Custom

    CLASS2.CUSTOM

## Description

An implementer can design their own events in this class. Care must be taken not to cause conflicts by selecting types used by other implementors. 

## Type=0 (0x00) - General event :id=type0
```
VSCP2_TYPE_CUSTOM_GENERAL
```
General Event.

----

[filename](./bottom_copyright.md ':include')