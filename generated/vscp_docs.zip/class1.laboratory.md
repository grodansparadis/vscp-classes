# Class=510 (0x01FE) - Laboratory use

    CLASS1.LABORATORY

## Description

This class is intended for lab usage. No production device should use this event type. 

## Type=0 (0x00) - General event :id=type0
```
VSCP_TYPE_LABORATORY_GENERAL
```
General Event.
----

[filename](./bottom_copyright.md ':include')